# Live settings for the Simple Replit edition

Start with the demo in README.md. Add sensitive values individually in Replit's Secrets tool, preserving any other settings. Public settings/flags can go in its Configurations section. Wallets and prices are already set in `config.json`.

| Name | Value |
| --- | --- |
| STREAMBOT_MODE | demo initially, live when ready |
| STREAMBOT_PUBLIC_URL | Exact HTTPS published origin, such as https://your-bot.replit.app, with no path |
| STREAMBOT_TELEGRAM_BOT_TOKEN | Token from official @BotFather |
| STREAMBOT_TELEGRAM_ENABLED | false initially, true to connect Telegram |
| STREAMBOT_SUPPORT_ADMIN_ID | Your numeric ID from /myid, sent from your @InterRamit account |
| STREAMBOT_PANEL_USERNAME | Reseller panel username |
| STREAMBOT_PANEL_PASSWORD | Reseller panel password |
| STREAMBOT_CREDENTIAL_KEY | Stable encryption key generated below |
| STREAMBOT_DATABASE_URL | Direct/session PostgreSQL connection URL |
| STREAMBOT_ETHEREUM_RPC_URL | Ethereum mainnet RPC supporting finalized blocks |
| STREAMBOT_SOLANA_RPC_URL | Solana mainnet RPC supporting finalized transaction history |
| STREAMBOT_BITCOIN_ESPLORA_URL | https://blockstream.info/api or your mainnet Esplora service |
| STREAMBOT_PANEL_WRITE_ENABLED | false initially; true for real account creation |
| STREAMBOT_LIVE_PAYMENTS_ENABLED | false initially; true for real payments |

Do not set STREAMBOT_BASE_PATH: this edition serves checkout at `/`. Leave STREAMBOT_PORT unset to use the configured 8090. Demo automatically uses Replit's Preview origin when REPLIT_DEV_DOMAIN is available. Override STREAMBOT_PUBLIC_URL only if needed for the actual origin, then use your published origin in production.

## Encryption key

After the first demo run, generate a key in Shell:

```bash
.venv/bin/python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Save the output as STREAMBOT_CREDENTIAL_KEY, keep a private backup, and never change it while using the same database. Never send it in chat or put it in a public source file.

## Database

Live Replit operation requires PostgreSQL; local SQLite is for the demo only. Add a direct PostgreSQL URL as STREAMBOT_DATABASE_URL. Do not use a transaction pooler: the app holds a session advisory lock to prevent two instances processing the same state. A session-pooled endpoint is also suitable if session semantics are guaranteed. The user needs permission to create its own schema. Demo and live use separate schemas `stream_panel_bot_demo` and `stream_panel_bot_live`. A stable encryption key is required even for a PostgreSQL demo.

Keep the database and encryption key across republishes. Replacing the database loses order history, used-TXID protection and trial limits. Local demo data is not automatically migrated.

## Check before activation

```bash
bash run.sh check
bash run.sh inspect-panel
```

The second command logs in and lists packages without creating an account. It requires panel credentials. Verify the packages, wallets and prices in config.json. Current paid packages exclude adult content.

## Publish

Select Reserved VM > Web server with one instance, use build `bash install.sh` and run `bash run.sh`. Expose only port 8090 as external 80, already specified in `.replit`. Review the Production app secrets in Publishing and use the exact published HTTPS origin for STREAMBOT_PUBLIC_URL. The Telegram long poller needs always-on hosting. Do not run Preview and production against the same bot token or live schema. If reusing a bot token with a webhook, remove its webhook before enabling long polling.

After every required live setting is present, set STREAMBOT_MODE=live, STREAMBOT_TELEGRAM_ENABLED=true, STREAMBOT_PANEL_WRITE_ENABLED=true and STREAMBOT_LIVE_PAYMENTS_ENABLED=true, then republish. Request one `/trial` and verify its real account in the panel. Test a controlled paid order and verify delivery before accepting customers. Paid provisioning spends panel credits. Live payment/account delivery has not been tested in the delivered package.

## Support and operations

Customers send `/contact` or `/support` to open a 24-hour support session. They consent to share their message and Telegram identity with you. You reply using Telegram's Reply action on the forwarded message or support header. `/cancel` stops new forwarding. Reply routes last 30 days and survive database-backed restarts. Your numeric admin ID is the authorization check; a matching username does not grant access. Message contents are copied through Telegram rather than stored as text in the database; encrypted delivery/routing metadata is stored. Telegram retains the chat copies. Protected/service messages cannot be copied; a crash after a successful API send but before its receipt is saved can cause a repeated message.

```bash
bash run.sh orders
bash run.sh reconcile ORDER_ID
```

An ambiguous panel creation result moves the order to `review` and stops automatic retries. Reconcile looks for the stored credentials without submitting creation again. If it confirms a match, the order is fulfilled. Only after verifying absence manually, `bash run.sh retry ORDER_ID --confirm-absent` queues one new attempt after another absence lookup.

The Telegram assistant handles trials, status and support. Purchasing, wallet instructions, TXID entry and delivery are on this external checkout site. The bot contains no paid shop or checkout link. Share the checkout address separately.

## Official Replit references

- https://docs.replit.com/features/project-setup/configuration
- https://docs.replit.com/features/publishing/deployment-types
- https://docs.replit.com/core-concepts/project-editor/app-setup/secrets
